#!/usr/bin/env python
# -*- coding: utf-8 -*-

class parameters :
	def __init__(self):
		#simulation 
		self.mouse_sleepness = 0.1
		#nombre de coups pour l'entrainement
		self.training = 1000
		#nombre de coups maximum que peut effectuer le chat lors du concours
		#avant d'etre declare comme perdant.
		self.run = 10000


		#constantes
		##############
		# exploration
		self.exploration_coeff = 0.9
		#self.exploration_coeff = 1.0
		#avec une valeur de 0.998, le coeff d'exploration retombe a 0.121 apres 1000 coups
		#avec une valeur de 0.9998 on est a 0.121 apres 10.000 coups	
		# 0.9996 donne 0.121 apres 5000 coups
		# 0.99996 donne 0.121 apres 50000 coups
		# 0.9999 pour 20000
		self.explore_decrease = 0.9996
		#self.explore_decrease = 1.0
		#amortissement de l'expected return
		self.gamma = 0.99
		#learning rate
		self.alpha = 1.0
		#decay of the learning rate
		#self.decay = self.explore_decrease*self.explore_decrease
		self.decay = 0.9999

		#parametres du probleme
		##########################
		#les deux dimensions
		#self.size = [10,10]
		self.size = [5,5]


		# Le probleme est prevu initialement pour
		# au moins un chat et une souris
		# Changer le nombre requierent d'implementer en fonction
		# les objets agent dans main.py		

		# un tableau contenant les coordonnees des chats
		# Les chats doivent etre deux ou plus (voire tout seul)
		self.cats_pos = [[4,1],[2,1]]
		#self.cats_pos = [[0,3],[2,1],[4,2]]
		#self.cats_pos = [[0,0],[4,0],[4,4]]
		#self.cats_pos = [[4,3],[2,8]]
		#self.cats_pos = [[4,3],[2,8],[2,2]]
		# un tableau contenant les coordonnees des souris
		# La souris doit etre seul
		self.mouse_pos = [[2,2]]
		# Les obstactles. Le tableau peut etre vide ou contenir un nombre
		# indetermine de pierres.
		#self.stones_pos = [[4,6]]
		self.stones_pos = []
		#self.stones_pos = [[0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],[0,8],[0,9],
#							[0,0],[1,0],[2,0],[3,0],[4,0],[5,0],[6,0],[7,0],[8,0],[9,0],]

		#Constantes d'affichage
		####################
		self.k = 50
		self.size_x = self.k*self.size[0]
		self.size_y = self.k*self.size[1]
		#temps a attendre entre chaque coup.
		self.to_sleep = 0.1
