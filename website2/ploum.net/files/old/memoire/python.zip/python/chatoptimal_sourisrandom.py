#!/usr/bin/env python
# -*- coding: utf-8 -*-
from livewires import *
import random

class animal :
	def __init__(self,x,y,size,color) :
		self.size_x = 640
		self.size_y = 480
		self.k = 10
		self.me = circle(x,y,size,filled=color)
		self.x = x
		self.y = y
		self.move

	def coord(self) :
		return [self.x,self.y]
	
	def move(self, mv) :
		if mv == 1 :
			self.up()
		elif mv == 2 :
			self.right()
		elif mv == 3 :
			self.bottom()
		elif mv == 4 :
			self.left()
		else :
			self.do_move()

	def left(self) :
		self.x = self.x - self.k
		self.do_move()
	
	def right(self) :
		self.x = self.x + self.k
		self.do_move()	

	def up(self) :
		self.y = self.y + self.k
		self.do_move()	

	def bottom(self) :
		self.y = self.y - self.k
		self.do_move()	

	def do_move(self):
		if self.x >= self.size_x :
		    self.x = self.x - self.size_x
		if self.y >= self.size_y :
		    self.y = self.y - self.size_y
		if self.x < 0 :
		    self.x = self.x + self.size_x
		if self.y < 0 :
		    self.y = self.y + self.size_y
		move_to(self.me, self.x, self.y)

class environnement :
	def __init__(self,agents, objectif) :
		self.agents=agents
		self.obj = objectif
		self.size_x = 640
		self.size_y = 480
		self.k = 10
	
	def goal(self):
		goal = 0
		for i in self.agents :
			if i.coord() == self.obj.coord() :
				goal = 1
		return goal

	def value_agent(self,agent) :
		tmp = self.distance(agent.coord(),self.obj.coord())
		return 0-tmp

	def best_move(self,agent) :
		best = 0
		actual = self.value_agent(agent)
		agent.up()
		up = self.value_agent(agent)
		agent.bottom()
		if up > actual :
			best = 1
			actual = up
		agent.bottom()
		bot = self.value_agent(agent)
		agent.up()
		if bot > actual :
			best = 3
			actual = bot
		agent.left()
		left = self.value_agent(agent)
		agent.right()
		if left > actual :
			best = 4
			actual = left
		agent.right()
		right = self.value_agent(agent)
		agent.left()
		if right > actual :
			best = 2
			actual = right
		#print  "up: %d -bot: %d -right: %d -left: %d = %d"%(up,bot,right,left,best)
		return best
		

	def distance(self,a,b) :
		k_x = self.size_x
		k_y = self.size_y
		distance = 0
		### X###
		if a[0] < b[0] :
			horiz1 = b[0] - a[0]
			horiz2 = k_x - b[0] + a[0]
			if horiz1 < horiz2 :
				distance += horiz1
			else :
				distance += horiz2
		elif a[0] > b[0] :
			horiz1 = a[0] - b[0]
			horiz2 = k_x - a[0] + b[0]
			if horiz1 < horiz2 :
				distance += horiz1
			else :
				distance += horiz2
		### y ####
		if a[1] < b[1] :
			horiz1 = b[1] - a[1]
			horiz2 = k_y - b[1] + a[1]
			if horiz1 < horiz2 :
				distance += horiz1
			else :
				distance += horiz2
		elif a[1] > b[1] :
			horiz1 = a[1] - b[1]
			horiz2 = k_y - a[1] + b[1]
			if horiz1 < horiz2 :
				distance += horiz1
			else :
				distance += horiz2
		return distance
		

if __name__ == "__main__":
	begin_graphics()
	allow_moveables()
	cat1 = animal(300,200,5,1)
	mouse = animal(100,400,5,0)
	env = environnement([cat1],mouse)
	i = 0
	moves = 0
	while env.goal() == 0 :
		cat1.move(env.best_move(cat1))
		moves += 1
		mouse.move(random.randint(0,4))
		#cat1.right()
		#mouse.left()
		#cat1.bottom()
		#mouse.up()
		i += 1
		#print "@@@@@@@@@@"
		#print env.value_agent(cat1)
		time.sleep(0.1)
	end_graphics()
	print "%d mouvements pour attraper la souris" %moves
