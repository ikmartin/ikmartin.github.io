#!/usr/bin/env python
# -*- coding: utf-8 -*-
from livewires import *
import values

#this is a display implementation. Simply implement a show(matrice) method that receive
# the env matrice as an argument.
def show(matrice) :
	valeurs = values.parameters()
	clear_screen()
	i = 0
	while i <= valeurs.size_x :
		j=0
		while j <= valeurs.size_y :
			box(i,j,i+valeurs.k,j+valeurs.k)
			j += valeurs.k
		i += valeurs.k
	allow_moveables()
	def place(x,y,color):
		size = 0.4*valeurs.k
		posx = (x+0.5)*valeurs.k
		posy = (y+0.5)*valeurs.k
		#if color == 0 :
		#	posx = posx - (valeurs.k*0.5)
		#	posy = posy - (valeurs.k*0.5)
		#	o=box(x,y,x+valeurs.k,y+valeurs.k,filled=0)
			#move_to(o, posx, posy)
		if color == 1 :
			o=circle(posx,posy,size,filled=2)
			#move_to(o, posx, posy)
		if color == 2 :
			o=circle(posx,posy,size,filled=0)
			#move_to(o, posx, posy)
		if color == 3 :
			posx = posx - (valeurs.k*0.5)
			posy = posy - (valeurs.k*0.5)
			o=box(posx,posy,posx+valeurs.k,posy+valeurs.k,filled=1)
			#move_to(o, posx, posy)
	ii = 0
	while ii < len(matrice) :
		jj = 0
		while jj < len(matrice[ii]) :
			place(ii,jj,matrice[ii][jj])
			jj += 1
		ii += 1
	o = circle(0,0,0,filled=0)
	move_to(o,0,0)
	time.sleep(valeurs.to_sleep)
