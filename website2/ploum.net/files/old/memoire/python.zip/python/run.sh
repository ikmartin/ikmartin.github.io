#!/bin/bash
i=0
runs=10
while [ $i -lt $runs ]; do
   python main.py
   i=$(($i+1))
  done
  
