#!/usr/bin/env python
# -*- coding: utf-8 -*-
import random
from ml import *
from ml_envir import *
from objets import *
import display
import values
import os

global goal

if __name__ == "__main__":
	global valeurs
	global players
	goal = 0
			
	valeurs = values.parameters()
	size = valeurs.size
	####### MODIFY HERE #############
	#Cats
	c_position = valeurs.cats_pos
	#Mouse : adding multiples mouse can have unpredicable results
	s_position = valeurs.mouse_pos
	#Stones (cannot be moved)
	stone_pos= valeurs.stones_pos
	##################
	begin_graphics(width=valeurs.size_x, height=valeurs.size_y)

	
	#matrice =[[0,0,0,0,0,0,0,0,0,0],
	#		  [0,2,0,0,0,0,1,0,0,0],
	#		  [0,0,0,0,0,0,0,0,0,0],
	#		  [0,0,0,0,0,0,0,0,0,0],
	#		  [0,0,0,0,0,0,0,0,0,0],
	#		  [0,0,0,0,0,0,0,0,0,0],
	#		  [0,0,0,0,0,0,0,0,0,0],
	#		  [0,0,0,0,0,0,0,0,0,0],
	#		  [0,0,0,0,1,0,0,0,0,0],
	#		  [0,0,0,0,0,0,0,0,0,0]]
	#show(matrice)

	#sleep(1000)



	
	objchat = obj_chat(c_position)
	objsouris = obj_souris(s_position)
	objstone = obj_stone(stone_pos)


	envi = obj_env(size)
	espace = envir(envi)
	chats = espace.addagent(objchat,c_position)
	souris = espace.addagent(objsouris,s_position)
	stones = espace.addagent(objstone,stone_pos)
	display.show(espace.display())
	
	count = 0
	training = valeurs.training
	run = valeurs.run
	cent = 0
	centaine = 0
	learn_goal = 0
	while  count < training :
		result = chats.best_move()
		if result.count(2) >= 1 :
			print "reinitialize the space"
			espace.reinit()
			learn_goal += 1
		r = random.random()
		if r >= valeurs.mouse_sleepness :
			souris.best_move()
		count += 1
		cent +=1
		if cent >= 100 :
			centaine += 1
			cent = 0
			print "%d mouvements ont ete appris"%(100*centaine)
		
		#display.show(espace.display())
		

	print "on a atteind %d fois le goal durant l'apprentissage"%learn_goal
	b = learn_goal
	print "######### Q ###########"
	c = espace.q_infos()
	print "########## V ############"
	espace.v_infos()
	print "########## pi ############"
	espace.pi_infos()
	
	espace.reinit()
	#print espace.display()
	display.show(espace.display())
	#time.sleep(1000)

	#valeurs.exploration_coeff = 1.0
	count = 0
	cent = 0
	centaine = 0
	while chats.best_move().count(2) < 1 :
		r = random.random()
		if r >= valeurs.mouse_sleepness :
			souris.best_move()
		count += 1
		#print "Mouvement num %d"%count
		display.show(espace.display())
		#print espace.display()
		if count > run :
			break
		if cent >= 100 :
			centaine += 1
			cent = 0
			print "%d mouvements ont ete realises"%(100*centaine)
	print "on a fait %d mouvements"%count
	a = count
	print"\n\nApres le run\n\n"
	print "######### Q ###########"
	espace.q_infos()
	print "########## V ############"
	espace.v_infos()
	print "########## pi ############"
	espace.pi_infos()

	abc = "%d (%d) [%d]\n"%(a,b,c)
	fd=open("result.txt",mode ='a+')
	fd.write(abc)
	fd.close()
	
	#chats.do_action(5)
	#espace.display()
	#souris.best_move()
	#souris.best_move()
	#souris.best_move()
	#espace.display()
